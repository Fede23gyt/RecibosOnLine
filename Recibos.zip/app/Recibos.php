<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Recibos extends Model
{
  protected $table = 'liquidaciones';
  public $timestamps = false;
}
