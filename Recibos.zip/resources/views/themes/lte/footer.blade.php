<footer class="main-footer">
  <strong>Colegio José Manuel Estrada 2020 - </strong>Todos los derechos reservados.
  <div class="float-right d-none d-sm-inline-block">
    <b>Version</b> 1.0
  </div>
</footer>
