<?php $__env->startSection('contenido'); ?>
  <div class='container'>
    <div class="row">
      <div class="col-12">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title"><b>Listado de Liquidaciones de Sueldo</b></h3>

          </div>

          <div class="card-body">
            <table id="listadorecibos" class="table table-bordered table-striped">
              <thead>
                <tr align="center">
                  <th>Apellido y Nombre</th>
                  <th>DNI</th>
                  <th>Cargo</th>
                  <th>Año</th>
                  <th>Mes</th>
                  <th>Total Neto</th>
                  <th>Descargar</th>
                </tr>
              </thead>
              <tbody>
              <?php $__currentLoopData = $recibos_usu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recibos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo $recibos->nombre; ?></td>
                <td align="center"><?php echo $recibos->dni; ?></td>
                <td align="center"><?php echo $recibos->cargo; ?></td>
                <td align="center"><?php echo $recibos->ano_liq; ?></td>
                <td align="center"><?php echo $recibos->mes_liq; ?></td>
                <td align="right">$&nbsp;<?php echo $recibos->liqu; ?></td>
                <td class="text-center py-0 align-middle">
                  <div class="btn-group btn-group-sm">
                  <a href="<?php echo e(route('descargar', $recibos->id)); ?>" class="btn btn-info"><i class="far fa-file-pdf"></i></a>
                  </div>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </tbody>
            </table>
          </div>

        </div>

      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('themes.lte.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\ProyectosLaravel\RecibosOnLine\resources\views/recibos/misrecibos.blade.php ENDPATH**/ ?>