<?php $__env->startSection('contenido'); ?>
<div class='container'>
  <!--Estas logueado
  <?php echo e(Auth::user()->dni); ?>

  -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('themes.lte.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\ProyectosLaravel\RecibosOnLine\resources\views/home.blade.php ENDPATH**/ ?>