<?php $__env->startSection('content'); ?>


<!-- Main Content -->
<div class="container" style="background-color: #ffffff" >

  <div class="login-box">

    <div class="row align-items-center text-center">
        <div class="col-sm-4">
        <img src=" <?php echo e(asset('Logo.png')); ?>">
        </div>
        <div class="col-sm-8 text-center">

          <div class="row"><h4 style="color:#a12a2a">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            &nbsp;&nbsp;&nbsp;&nbsp;&nbspCOLEGIO</h4></div>
          <div class="row"><h4 style="color:#a12a2a">JOSE MANUEL ESTRADA</h4></div>
        </div>


    </div>

    <div class="card">
      <div class="card-body login-card-body">
        <form method="POST" action="<?php echo e(route('login')); ?>" >
          <?php echo csrf_field(); ?>
          <div class="input-group mb-3">
            <input type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
              name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus placeholder="Email" id="email" >
              <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            <div class="input-group-append">
              <div class="input-group-text">
                <span class="fas fa-envelope"></span>
              </div>
            </div>
          </div>

          <div class="input-group mb-3">
            <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password"
            required autocomplete="current-password" placeholder="Contraseña">
              <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                <span class="invalid-feedback" role="alert">
                  <strong><?php echo e($message); ?></strong>
                </span>
              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
              <div class="input-group-append">
                <div class="input-group-text">
                  <span class="fas fa-lock"></span>
                </div>
              </div>
          </div>

          <div class="row">
            <div class="col-8">
              <div class="icheck-primary">
                <input type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                <label for="remember">
                  Recordarme
                </label>
              </div>
            </div>
            <!-- /.col -->
            <div class="col-4">
              <button type="submit" class="btn btn-block btn-outline-warning">Ingresar</button>
            </div>
            <!-- /.col -->
          </div>
        </form>
      </div>
      <!-- /.login-card-body -->
    </div>
  </div>
  <!-- /.login-box -->
</div>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\ProyectosLaravel\RecibosOnLine\resources\views/auth/login.blade.php ENDPATH**/ ?>