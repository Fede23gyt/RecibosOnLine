@extends('themes.lte.layout')

@section('contenido')
<div class='container'>

</div>
@endsection
